import axios from 'axios'
import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'

const endpoint = 'http://localhost:8000/api/personaje'
const CreateCharacter = () => {

    const [name, setName] = useState('')
    const [height, setHeight] = useState('')
    const [mass, setMass] = useState('')
    const [hair_color, setHairColor] = useState('')
    const [skin_color, setSkinColor] = useState('')
    const [eye_color, setEyeColor] = useState('')
    const [birth_year, setBirth] = useState('')
    const [gender, setGender] = useState('')
    const [homeworld, setHomeworld] = useState('')
    const navigate = useNavigate()

    const store = async (e) => {
        e.preventDefault();

        await axios.post(endpoint, {name: name, height: height, mass: mass, hair_color: hair_color, skin_color: skin_color, eye_color: eye_color, birth_year: birth_year, gender: gender, homeworld: homeworld})
        navigate('/')

    }
  return (
    <div>
        <h2>Creat a new employee</h2>
        <form onSubmit={store}>
            <div className='mb-3'>
                <label className='form-label'>Name</label>
                <input 
                    value={name} 
                    onChange={ (e)=> setName(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Height</label>
                <input 
                    value={height} 
                    onChange={ (e)=> setHeight(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Mass</label>
                <input 
                    value={mass} 
                    onChange={ (e)=> setMass(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Hair Color</label>
                <input 
                    value={hair_color} 
                    onChange={ (e)=> setHairColor(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Skin Color</label>
                <input 
                    value={skin_color} 
                    onChange={ (e)=> setSkinColor(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Eye Color</label>
                <input 
                    value={eye_color} 
                    onChange={ (e)=> setEyeColor(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Birth Year</label>
                <input 
                    value={birth_year} 
                    onChange={ (e)=> setBirth(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Gender</label>
                <input 
                    value={gender} 
                    onChange={ (e)=> setGender(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Homeworld</label>
                <input 
                    value={homeworld} 
                    onChange={ (e)=> setHomeworld(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <button type='submit' className='btn btn-success'>Save</button>
        </form>
    </div>
  )
}

export default CreateCharacter
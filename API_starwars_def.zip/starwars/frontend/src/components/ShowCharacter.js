import React, {useEffect, useState} from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'

const endpoint = 'http://localhost:8000/api'


const ShowCharacter = () => {

    const [personajes, setCharacter] = useState([])
    useEffect ( ()=> {
        getAllCharacters()
    }, [])

    const getAllCharacters = async () => {
        const response = await axios.get(`${endpoint}/personajes`)
        setCharacter(response.data)
    }

    const deleteCharacter = async (id) => {

       await axios.delete(`${endpoint}/personaje/${id}`)
       getAllCharacters()
         
    }
  return (
    <div>
        <div className='d-grid gap-2'>
            <Link to="/create" className='btn btn-success btn-lg mt-2 mb-2 text-white'>Create</Link>
        </div>
        <table className='table table-striped'>
            <thead className='bg-primary text-white'>
                <tr>
                    <th>name</th>
                    <th>height</th>
                    <th>mass</th>
                    <th>hair_color</th>
                    <th>skin_color</th>
                    <th>eye_color</th>
                    <th>birth_year</th>
                    <th>gender</th>
                    <th>homeworld</th>
                </tr>
            </thead>
            <tbody>
                { personajes.map( (personaje) => (
                    <tr key={personaje.id}>
                        <td>{personaje.name}</td>
                        <td>{personaje.height}</td>
                        <td>{personaje.mass}</td>
                        <td>{personaje.hair_color}</td>
                        <td>{personaje.skin_color}</td>
                        <td>{personaje.eye_color}</td>
                        <td>{personaje.birth_year}</td>
                        <td>{personaje.gender}</td>
                        <td>{personaje.homeworld}</td>
                        <td>
                            <Link to={`/edit/${personaje.id}`} className='btn btn-info'>Edit</Link>
                            <button onClick={ ()=>deleteCharacter(personaje.id)} className='btn btn-danger'>Delete</button>
                        </td>
                    </tr>
                ))}                
            </tbody>
        </table>
    </div>
  )
}

export default ShowCharacter
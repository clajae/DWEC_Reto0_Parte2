import axios from 'axios'
import React,{useState, useEffect} from 'react'
import { useNavigate, useParams } from 'react-router-dom'

const endpoint = 'http://localhost:8000/api/personaje/'

const EditCharacter = () => {

    const [name, setName] = useState('')
    const [height, setHeight] = useState('')
    const [mass, setMass] = useState('')
    const [hair_color, setHairColor] = useState('')
    const [skin_color, setSkinColor] = useState('')
    const [eye_color, setEyeColor] = useState('')
    const [birth_year, setBirth] = useState('')
    const [gender, setGender] = useState('')
    const [homeworld, setHomeworld] = useState('')
    const navigate = useNavigate()
    const {id} = useParams()

    const update = async (e) => {
        e.preventDefault();
        await axios.put(`${endpoint}${id}`, {
            name: name,
            height: height,
            mass: mass,
            hair_color: hair_color,
            skin_color: skin_color,
            eye_color: eye_color,
            birth_year: birth_year,
            gender: gender,
            homeworld: homeworld
        })
        navigate('/')
    }

    useEffect( () =>{

        const getCharacterById = async () => {
            const response = await axios.get(`${endpoint}${id}`)
            setName(response.data.name)
            setHeight(response.data.height)
            setMass(response.data.mass)
            setHairColor(response.data.hair_color)
            setSkinColor(response.data.skin_color)
            setEyeColor(response.data.eye_color)
            setBirth(response.data.birth_year)
            setGender(response.data.gender)
            setHomeworld(response.data.homeworld)
        }
        getCharacterById()
        
    }, [])
  return (
    <div>
        <h2>Edit character</h2>
        <form onSubmit={update}>
            <div className='mb-3'>
                <label className='form-label'>Name</label>
                <input 
                    value={name} 
                    onChange={ (e)=> setName(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Height</label>
                <input 
                    value={height} 
                    onChange={ (e)=> setHeight(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Mass</label>
                <input 
                    value={mass} 
                    onChange={ (e)=> setMass(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Hair Color</label>
                <input 
                    value={hair_color} 
                    onChange={ (e)=> setHairColor(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Skin Color</label>
                <input 
                    value={skin_color} 
                    onChange={ (e)=> setSkinColor(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Eye Color</label>
                <input 
                    value={eye_color} 
                    onChange={ (e)=> setEyeColor(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Brith Year</label>
                <input 
                    value={birth_year} 
                    onChange={ (e)=> setEyeColor(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Gender</label>
                <input 
                    value={gender} 
                    onChange={ (e)=> setGender(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <div className='mb-3'>
                <label className='form-label'>Homeworld</label>
                <input 
                    value={homeworld} 
                    onChange={ (e)=> setHomeworld(e.target.value)}
                    type='text'
                    className='form-control'
                />
            </div>

            <button type='submit' className='btn btn-success'>Update</button>
        </form>
    </div>
  )
}

export default EditCharacter
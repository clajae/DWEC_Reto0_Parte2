import './App.css';

import { BrowserRouter, Routes, Route } from 'react-router-dom';
//se importa el componente
import ShowCharacter from './components/ShowCharacter';
import CreateCharacter from './components/CreateCharacter';
import EditCharacter from './components/EditCharacter';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path='/' element={ <ShowCharacter/>} />
          <Route path='/create' element={ <CreateCharacter/>} />
          <Route path='/edit/:id' element={ <EditCharacter/>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
